import express from 'express'
import bodyParser from 'body-parser';
import cors from 'cors';

import marcasRoutes from './src/routes/marcas.routes.js';
import modelosRoutes from './src/routes/modelos.routes.js';

const app = express();
app.use(bodyParser.json());
app.use(cors());

app.get('/', (req, resp) => {
  return resp.json({ message: "HEALTHY", code: 200})
})

app.use('/marcas', marcasRoutes);
app.use('/modelos', modelosRoutes);

export default app;