import repository from '../repositories/marcas.repository.js';

const findAll = async (req, res) => {
    const result = await repository.findAll();
    return sendResponse(result, res);
};

const create = async (req, res) => {
    const result = await repository.create(req.body);
    return sendResponse(result, res);
};

const sendResponse = (result, res) => {
    if (result) {
        return res.status(200).json(result);
    }
    return res.status(500).json({ message: 'Ha ocurrido un error.' });
};

export default { findAll, create };