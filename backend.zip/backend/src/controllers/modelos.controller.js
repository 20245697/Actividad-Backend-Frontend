import repository from '../repositories/modelos.repository.js';

const findAll = async (req, resp) => {
    const respuesta = await repository.findAll();
    return sendResponse(respuesta, "No se encontró.", 404, resp);
}

const create = async (req, resp) => {
    const payload = req.body;
    const respuesta = await repository.create(payload);

    return sendResponse(respuesta, "No se pudo crear.", 400, resp);
}

const sendResponse = (respuesta, mensajeError, codigoError, resp) => {
    if (respuesta) {
        return resp.status(200).json(respuesta);
    } else {
        return resp.status(codigoError).json({ message: mensajeError });
    }
}

const controller = { findAll, create };

export default controller;