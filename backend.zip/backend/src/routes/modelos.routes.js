import express from 'express';
import controller from '../controllers/modelos.controller.js';

const router = express.Router();

router.get('/', controller.findAll);
router.post('/', controller.create);

export default router;