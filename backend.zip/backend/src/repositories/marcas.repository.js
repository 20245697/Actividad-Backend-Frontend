import { Marca, Modelo } from '../models/relaciones.js';
import RepositoryBase from './RepositoryBase.js';

const repository = new RepositoryBase(Marca);

repository.findAll = async () => {
    try {
        return await Marca.findAll({
        include: [{ model: Modelo, as: 'modelos' }],
        order: ['id']
        });
    } catch (err) {
        console.log(err);
        return null;
    }
};

repository.create = async (payload) => {
    try {
        return await Marca.create(payload);
    } catch (err) {
        console.log(err);
        return null;
    }
};

export default repository;