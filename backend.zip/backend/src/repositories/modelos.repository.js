import { Marca, Modelo } from '../models/relaciones.js';
import RepositoryBase from './RepositoryBase.js';

const repository = new RepositoryBase(Modelo);

repository.findAll = async () => {
    try {
        return await Modelo.findAll({
        include: [{ model: Marca, as: 'marca' }],
        order: ['id']
        });
    } catch (err) {
        console.log(err);
        return null;
    }
};

repository.create = async (payload) => {
    try {
        return await Modelo.create(payload);
    } catch (err) {
        console.log(err);
        return null;
    }
};

export default repository;