import Marca from './marcas.js';
import Modelo from './modelos.js';

Marca.hasMany(Modelo, { foreignKey: 'idMarca', as: 'modelos' });
Modelo.belongsTo(Marca, { foreignKey: 'idMarca', as: 'marca' });

export { Marca, Modelo };