import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

const Modelo = sequelize.define('Modelo', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    nombre: {
        type: DataTypes.STRING
    },
    idMarca: {
        type: DataTypes.INTEGER
    }
});

export default Modelo;