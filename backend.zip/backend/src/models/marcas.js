import sequelize from '../config/database.js';
import { DataTypes } from 'sequelize';

const Marca = sequelize.define('Marca', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    nombre: {
        type: DataTypes.STRING
    },
    pais: {
        type: DataTypes.STRING
    }
});

export default Marca;