import sequelize from "../config/database.js";
import { Marca, Modelo } from "../models/relaciones.js";

const marcas = [
    {
        id: 1,
        nombre: "Toyota",
        pais: "Japón"
    },
    {
        id: 2,
        nombre: "Ford",
        pais: "Estados Unidos"
    },
    {
        id: 3,
        nombre: "BMW",
        pais: "Alemania"
    }
];

const modelos = [
    {
        id: 1,
        nombre: "Corolla",
        idMarca: 1
    },
    {
        id: 2,
        nombre: "Yaris",
        idMarca: 1
    },
    {
        id: 3,
        nombre: "Mustang",
        idMarca: 2
    },
    {
        id: 4,
        nombre: "Serie 3",
        idMarca: 3
    }
];

const migrate = async () => {
    try {
        await sequelize.sync({ force: true });
        await Marca.bulkCreate(marcas);
        await Modelo.bulkCreate(modelos);
        console.log("Migración completada correctamente.");
    } catch (error) {
        console.error("Error en la migración:", error);
    } finally {
        await sequelize.close();
    }
};

migrate();